# yolov8 获取模型指标
from ultralytics import YOLO

def main():
    pt_file_address = r"D:\YOLO\ultralytics-8.3.6\runs\train\exp52\weights\best.pt"
    model = YOLO(pt_file_address)
    metrics = model.val()

    print("Precision:", metrics.box.p)
    print("Recall:", metrics.box.r)
    print("mAP@0.5:", metrics.box.map50)
    print("mAP@0.75:", metrics.box.map75)
    print("Precision:", metrics.results_dict['metrics/precision(B)'])

if __name__ == '__main__':
    main()