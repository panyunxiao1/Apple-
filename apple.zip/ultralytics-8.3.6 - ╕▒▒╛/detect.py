# -*- coding: utf-8 -*-
"""
@Auth ： 挂科边缘
@File ：detect.py
@IDE ：PyCharm
@Motto:学习新思想，争做新青年
@Email ：179958974@qq.com
"""

from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO(model=r'D:\YOLO\ultralytics-8.3.6\runs\train\exp46\weights\best.pt')
    model.predict(
        source=r'C:\Users\PYX\Desktop\chuli\dingwei\images',
        save=True,         # ✅ 保存带框的图片
        save_txt=True,     # ✅ 保存检测框为 .txt 文件
        save_conf=True,    # ✅ 在 .txt 中保存置信度
        show=True          # 可选：检测时弹出窗口预览
    )